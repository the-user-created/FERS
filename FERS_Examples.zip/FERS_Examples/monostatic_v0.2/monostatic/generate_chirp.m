Phi = 0;                % initial phase [rad]
B = 1e6;                % chirp bandwidth [Hz]
Tm = 100e-6;            % pulse length [s]
Fs = 10e6;              % sampling frequency [Hz]
K = B/Tm;               % chirp rate [Hz/s]

t_pulse = linspace(0, Tm, Tm*Fs);

chirp = exp(1i*pi*K*t_pulse.^2 + 1i*Phi); % generate complex chirp

I = real(chirp);
Q = imag(chirp);

hdf5write('chirp.h5', '/I/value', I, '/Q/value', Q);
fprintf('Chirp Generated.\n');

